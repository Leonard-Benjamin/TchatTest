package com.example.tchattest.dataClasses

data class User(val name: String, val color: Int, val messageTextColor: Int? = null)